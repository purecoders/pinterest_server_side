<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SavedPost extends Model
{
  public function posts(){

  }
}
