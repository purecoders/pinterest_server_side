<?php $__env->startSection('content'); ?>
    <section id="actions" class="py-2 bg-light mb-1">
        <div class="container">
            <div class="row">
                <div class="col-md-6 my-1">
                    <input type="text" class="form-control" placeholder="Add tag">
                </div>
                <div class="col-md-6 my-1">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search">
                        <div class="input-group-append">
                            <button class="btn btn-primary">Search</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 my-1">
                    <button class="btn btn-success  btn-block"><i class="fa fa-plus"></i> Add tag</button>
                </div>
            </div>
    </section>

    <section id="posts">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto">
                    <div class="card">
                        <div class="card-header">
                            <h4>Lastest Tags</h4>
                        </div>
                        <table class="table table-striped">
                            <thead class="thead-dark">
                            <tr>
                                <th>#</th>
                                <th>Title</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td scope="row">1</td>
                                <td>tag one</td>
                                <td><a href="#" class="btn btn-primary" data-toggle="modal" data-target="#editTagModal">
                                        <i class="fa fa-edit"></i> edit
                                    </a></td>
                                <td><a href="#" class="btn btn-danger">
                                        <i class="fa fa-remove"></i> delete
                                    </a></td>
                            </tr>
                            <tr>
                                <td scope="row">2</td>
                                <td>tag two</td>
                                <td><a href="#" class="btn btn-primary" data-toggle="modal" data-target="#editTagModal">
                                        <i class="fa fa-edit"></i> edit
                                    </a></td>
                                <td><a href="#" class="btn btn-danger">
                                        <i class="fa fa-remove"></i> delete
                                    </a></td>
                            </tr>
                            <tr>
                                <td scope="row">3</td>
                                <td>tag three</td>
                                <td><a href="#" class="btn btn-primary" data-toggle="modal" data-target="#editTagModal">
                                        <i class="fa fa-edit"></i> edit
                                    </a></td>
                                <td><a href="#" class="btn btn-danger">
                                        <i class="fa fa-remove"></i> delete
                                    </a></td>
                            </tr>
                            <tr>
                                <td scope="row">4</td>
                                <td>tag four</td>
                                <td><a href="#" class="btn btn-primary" data-toggle="modal" data-target="#editTagModal">
                                        <i class="fa fa-edit"></i> edit
                                    </a></td>
                                <td><a href="#" class="btn btn-danger">
                                        <i class="fa fa-remove"></i> delete
                                    </a></td>
                            </tr>
                            <tr>
                                <td scope="row">5</td>
                                <td>tag five</td>
                                <td><a href="#" class="btn btn-primary" data-toggle="modal" data-target="#editTagModal">
                                        <i class="fa fa-edit"></i> edit
                                    </a></td>
                                <td><a href="#" class="btn btn-danger">
                                        <i class="fa fa-remove"></i> delete
                                    </a></td>
                            </tr>
                            <tr>
                                <td scope="row">6</td>
                                <td>tag six</td>
                                <td><a href="#" class="btn btn-primary" data-toggle="modal" data-target="#editTagModal">
                                        <i class="fa fa-edit"></i> edit
                                    </a></td>
                                <td><a href="#" class="btn btn-danger">
                                        <i class="fa fa-remove"></i> delete
                                    </a></td>
                            </tr>
                            </tbody>
                        </table>
                        <nav>
                            <ul class="pagination justify-content-center">
                                <li class="page-item disabled"><a href="#" class="page-link">Previous</a></li>
                                <li class="page-item "><a href="#" class="page-link">1</a></li>
                                <li class="page-item "><a href="#" class="page-link">2</a></li>
                                <li class="page-item "><a href="#" class="page-link">3</a></li>
                                <li class="page-item "><a href="#" class="page-link">4</a></li>
                                <li class="page-item "><a href="#" class="page-link">Next</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Tag Modal -->
    <div class="modal fade" id="editTagModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title">Edit Tag</h5>
                    <button class="close"data-dismiss="modal"><span class="text-light">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form action="">
                        <div class="form-group">
                            <label for="title2">Title</label>
                            <input id="title2" type="text" class="form-control">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-success">Save Changes</button>
                    <button class="btn btn-secondary" data-dismiss="modal">close</button>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>