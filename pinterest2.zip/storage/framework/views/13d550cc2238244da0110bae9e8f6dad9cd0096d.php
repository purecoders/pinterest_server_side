<?php $__env->startSection('content'); ?>
    <!-- Actions -->

    <section id="actions" class="py-4 bg-light mb-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6 ml-auto">


                    <div class="row">
                        <form action="<?php echo e(url('user-search')); ?>" method="post">
                            <?php echo csrf_field(); ?>

                            <div class="input-group">
                                <input name="text" type="text" class="form-control" placeholder="Search">
                                <div class="input-group-append">
                                    <input type="submit"  class="btn btn-primary" value="search">
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!--Usesr -->
    <section id="users">
        <div class="container">
            <div class="row">
                <div class="col-lg-9 mx-auto">
                    <div class="card">
                        <div class="card-header">
                            <h4>Lastest Users</h4>
                        </div>
                        <table id="tblMain" class="table table-striped">
                            <thead class="thead-dark">
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>user_name</th>
                                <th>Email</th>
                                <th>Block</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row"><?php echo e(++$key+(($users->currentPage()-1)*$users->perPage())); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->user_name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td class="tbl-tag-block">

                                        <a class="btn btn-danger" href="<?php echo e(url('user-delete', $user->id)); ?>">
                                            <i class="fa fa-ban"></i> Block
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <nav>
                            <ul class="pagination justify-content-center">
                                <?php echo e($users->links()); ?>

                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Delete Tag Modal -->
    <div class="modal fade" id="blockUserModal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title">Block User</h5>
                    <button class="close" data-dismiss="modal"><span class="text-light">&times;</span></button>
                </div>
                <form id="block-form" action="" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="_method" value="DELETE">
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Are You sure Block this User:</label>
                            <h5 id="block-modal-user-name"></h5>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-danger" type="submit">Yes,sure</button>
                        <button class="btn btn-secondary" data-dismiss="modal">close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>