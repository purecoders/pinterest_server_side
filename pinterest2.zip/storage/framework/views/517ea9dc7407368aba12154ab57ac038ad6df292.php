<?php echo $__env->make('template.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<nav class="navbar navbar-expand-sm navbar-dark bg-dark p-0">
    <div class="container">
        <a href="index.html" class="navbar-brand"><i class="fa fa-gear"></i> Control Panel</a>
        <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item px-2">
                    <a id="nav-link-tag"href="<?php echo e(route('tag.index')); ?>" class="nav-link">Tags</a>
                </li>
                <li class="nav-item px-2">
                    <a id="nav-link-user" href="<?php echo e(route('user.index')); ?>" class="nav-link">Users</a>
                </li>
            </ul>
            <ul class="navbar-nav ml-auto">
                <li class="nav-item nav-link">

                    <i class="fa-fa-user"></i> Welcome  <?php echo e(Auth::user()->name); ?>


                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('logout')); ?>" class="nav-link" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                        <i class="fa fa-user-times"></i> Logout
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('template.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>